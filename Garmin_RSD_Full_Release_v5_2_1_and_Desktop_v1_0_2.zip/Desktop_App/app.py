#!/usr/bin/env python3
import os, sys, tkinter as tk
from tkinter import ttk, filedialog, messagebox

# Import core that ships alongside
import importlib.util
spec = importlib.util.spec_from_file_location("rsd_core_crc_plus", os.path.join(os.path.dirname(__file__), "rsd_core_crc_plus.py"))
core = importlib.util.module_from_spec(spec); spec.loader.exec_module(core)

class App(tk.Tk):
    def __init__(self):
        super().__init__(); self.title("Garmin RSD Desktop (v1.0.2)") ; self.geometry("820x600")
        self.vars=dict(
            rsd=tk.StringVar(), parent=tk.StringVar(value=os.path.abspath("./rsd_runs")), run=tk.StringVar(value="run_app"),
            crc=tk.StringVar(value="warn"), resync=tk.IntVar(value=8), hdr=tk.BooleanVar(value=False),
            numba=tk.BooleanVar(value=True), threads=tk.IntVar(value=4),
            row=tk.IntVar(value=40), water=tk.IntVar(value=8), inv=tk.BooleanVar(value=True),
            lo=tk.DoubleVar(value=1.0), hi=tk.DoubleVar(value=99.0), gamma=tk.DoubleVar(value=1.0),
            slant=tk.BooleanVar(value=True), stride=tk.IntVar(value=4), swath=tk.DoubleVar(value=40.0),
            bucket=tk.BooleanVar(value=True), region=tk.BooleanVar(value=True),
            depthgps=tk.BooleanVar(value=True), gps=tk.DoubleVar(value=100.0), depe=tk.IntVar(value=20),
            depft=tk.DoubleVar(value=3.0), deppct=tk.StringVar(value=""),
            makevid=tk.BooleanVar(value=True), vfps=tk.IntVar(value=30), vheight=tk.IntVar(value=1080), vmax=tk.IntVar(value=20000)
        )
        self._build()
    def _build(self):
        V=self.vars; frm=ttk.Frame(self); frm.pack(fill="both", expand=True, padx=10, pady=10); r=0
        def row(lbl, w): ttk.Label(frm, text=lbl).grid(row=r, column=0, sticky="e"); w.grid(row=r, column=1, sticky="we"); return 1
        row("RSD file", ttk.Entry(frm, textvariable=V["rsd"])); ttk.Button(frm,text="Browse",command=self.pick_rsd).grid(row=r, column=2); r+=1
        row("Parent output", ttk.Entry(frm, textvariable=V["parent"])); ttk.Button(frm,text="Pick",command=self.pick_dir).grid(row=r, column=2); r+=1
        row("Run name", ttk.Entry(frm, textvariable=V["run"])); r+=1
        ttk.Separator(frm).grid(row=r,column=0,columnspan=3,sticky="we",pady=6); r+=1
        ttk.Label(frm,text="CRC / ResyncMB / ParseHeader / Numba / Threads").grid(row=r,column=0,sticky="e")
        sub=ttk.Frame(frm); sub.grid(row=r,column=1,sticky="w")
        ttk.Combobox(sub, values=["strict","warn","off"], textvariable=V["crc"], width=7).pack(side="left",padx=2)
        ttk.Entry(sub, textvariable=V["resync"], width=6).pack(side="left",padx=2)
        ttk.Checkbutton(sub, text="Hdr", variable=V["hdr"]).pack(side="left",padx=2)
        ttk.Checkbutton(sub, text="Numba", variable=V["numba"]).pack(side="left",padx=2)
        ttk.Entry(sub, textvariable=V["threads"], width=6).pack(side="left",padx=2); r+=1
        ttk.Label(frm,text="Row / WaterGap / Invert / Gamma").grid(row=r,column=0,sticky="e")
        sub2=ttk.Frame(frm); sub2.grid(row=r,column=1,sticky="w")
        ttk.Entry(sub2,textvariable=V["row"],width=6).pack(side="left",padx=2)
        ttk.Entry(sub2,textvariable=V["water"],width=6).pack(side="left",padx=2)
        ttk.Checkbutton(sub2,text="Invert",variable=V["inv"]).pack(side="left",padx=2)
        ttk.Entry(sub2,textvariable=V["gamma"],width=6).pack(side="left",padx=2); r+=1
        ttk.Label(frm,text="Clip Low/High %").grid(row=r,column=0,sticky="e")
        sub3=ttk.Frame(frm); sub3.grid(row=r,column=1,sticky="w")
        ttk.Entry(sub3,textvariable=V["lo"],width=6).pack(side="left",padx=2)
        ttk.Entry(sub3,textvariable=V["hi"],width=6).pack(side="left",padx=2); r+=1
        ttk.Label(frm,text="Stride / SS swath (m)").grid(row=r,column=0,sticky="e")
        sub4=ttk.Frame(frm); sub4.grid(row=r,column=1,sticky="w")
        ttk.Entry(sub4,textvariable=V["stride"],width=6).pack(side="left",padx=2)
        ttk.Entry(sub4,textvariable=V["swath"],width=6).pack(side="left",padx=2); r+=1
        for txt,key in [("Slant correction","slant"),("Bucketed KMZ","bucket"),("Regionated KMZ","region"),("Depth+GPS KMLs","depthgps")]:
            ttk.Checkbutton(frm,text=txt,variable=V[key]).grid(row=r,column=0,sticky="w"); r+=1
        ttk.Label(frm,text="GPS step (m) / Depth every pings / Δdepth ft / % change").grid(row=r,column=0,sticky="e")
        sub5=ttk.Frame(frm); sub5.grid(row=r,column=1,sticky="w")
        for k,w in [("gps",8),("depe",6),("depft",8)]: ttk.Entry(sub5,textvariable=V[k],width=w).pack(side="left",padx=2)
        ttk.Entry(sub5,textvariable=V["deppct"],width=8).pack(side="left",padx=2); r+=1
        ttk.Label(frm,text="Video (make/FPS/height/max frames)").grid(row=r,column=0,sticky="e")
        sub6=ttk.Frame(frm); sub6.grid(row=r,column=1,sticky="w")
        ttk.Checkbutton(sub6,text="Make",variable=V["makevid"]).pack(side="left",padx=2)
        ttk.Entry(sub6,textvariable=V["vfps"],width=6).pack(side="left",padx=2)
        ttk.Entry(sub6,textvariable=V["vheight"],width=8).pack(side="left",padx=2)
        ttk.Entry(sub6,textvariable=V["vmax"],width=8).pack(side="left",padx=2); r+=1
        ttk.Button(frm,text="Run",command=self.run_pipeline).grid(row=r,column=1,pady=10); frm.columnconfigure(1,weight=1)
    def pick_rsd(self):
        p=filedialog.askopenfilename(title="Choose RSD",filetypes=[("RSD","*.RSD"),("All files","*.*")])
        if p: self.vars["rsd"].set(p)
    def pick_dir(self):
        d=filedialog.askdirectory(title="Select output parent")
        if d: self.vars["parent"].set(d)
    def run_pipeline(self):
        V=self.vars
        rsd=V["rsd"].get().strip(); parent=V["parent"].get().strip(); run=V["run"].get().strip()
        if not (rsd and os.path.exists(rsd)):
            messagebox.showerror("Error","Pick a valid RSD"); return
        os.makedirs(parent, exist_ok=True)
        out_dir=os.path.join(parent, run); os.makedirs(out_dir, exist_ok=True)
        cfg=dict(CRC_MODE=V["crc"].get(), MAX_RESYNC_BYTES=int(V["resync"].get())*1024*1024, PARSE_HEADER=V["hdr"].get(),
                 USE_NUMBA=V["numba"].get(), THREADS=int(V["threads"].get()),
                 ROW_HEIGHT_PX=int(V["row"].get()), WATER_COLUMN_PX=int(V["water"].get()),
                 INVERT=V["inv"].get(), CLIP_LOW_PCT=float(V["lo"].get()), CLIP_HIGH_PCT=float(V["hi"].get()), GAMMA=float(V["gamma"].get()),
                 PALETTES=["amber","grayscale"], APPLY_SLANT=V["slant"].get(), STRIDE=int(V["stride"].get()), SWATH_M_SS=float(V["swath"].get()),
                 MAKE_BUCKETED_KMZ=V["bucket"].get(), MAKE_REGIONATED_KMZ=V["region"].get(),
                 MAKE_DEPTH_GPS=V["depthgps"].get(), GPS_STEP_M=float(V["gps"].get()), DEPTH_EVERY_PINGS=int(V["depe"].get()),
                 DEP_FT_THRESHOLD=float(V["depft"].get()), PCT_CHANGE_MIN=V["deppct"].get(),
                 PREVIEW_MAX_ROWS=2000,
                 MAKE_VIDEO=V["makevid"].get(), VIDEO_FPS=int(V["vfps"].get()), VIDEO_HEIGHT=int(V["vheight"].get()), VIDEO_MAX_FRAMES=int(V["vmax"].get()))
        try:
            summary = core.build_rows_and_assets(rsd, out_dir, cfg)
            messagebox.showinfo("Done", f"Rows: {summary['rows']}\nCRC: {summary.get('crc_mode')}\nOut: {summary['out_dir']}")
        except Exception as e:
            messagebox.showerror("Error", str(e))

if __name__=="__main__":
    App().mainloop()
