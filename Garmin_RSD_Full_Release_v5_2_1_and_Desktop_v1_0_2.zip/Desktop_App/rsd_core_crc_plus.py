
# rsd_core_crc_plus.py — core with CRC modes, resync, header-parse toggle, numba accel,
# threaded writes, bucketed & regionated KMZs, depth/GPS KMLs, robust preview + safe video
import os, math, mmap, struct, zlib, logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from typing import Optional, List, Tuple
import numpy as np
from PIL import Image

logging.getLogger().setLevel(logging.WARNING)

# ---- global toggles (can be modified by GUI) ----
CRC_MODE = "warn"               # 'strict' | 'warn' | 'off'
MAX_RESYNC_BYTES = 8 * 1024 * 1024
PARSE_HEADER = False            # try to parse header area varstructs
USE_NUMBA = False               # if True and numba available, JIT some kernels
THREADS = 4                     # for row PNG writes
EARTH_R = 6371000.0

try:
    if USE_NUMBA:
        from numba import njit
    else:
        raise ImportError
except Exception:
    def njit(*args, **kwargs):
        def wrap(f): return f
        return wrap

def meters_to_deg_lat(dy): return (dy / EARTH_R) * (180.0 / math.pi)
def meters_to_deg_lon(dx, lat): return (dx / (EARTH_R * math.cos(math.radians(lat)))) * (180.0 / math.pi)
def offset_latlon(lat, lon, dx_east_m, dy_north_m):
    return lat + meters_to_deg_lat(dy_north_m), lon + meters_to_deg_lon(dx_east_m, lat)

def read_varuint_from(mm, pos):
    res=0; shift=0; size=len(mm)
    while pos < size:
        b=mm[pos]; pos+=1
        res |= (b & 0x7F) << shift
        if not (b & 0x80): break
        shift+=7
    return res, pos

def zigzag_to_int32(u): return (u>>1) ^ (-(u & 1))

def crc32_ieee(data: bytes) -> int:
    return (zlib.crc32(data) ^ 0xFFFFFFFF) & 0xFFFFFFFF

def _read_varstruct_raw(mm, pos, size, *, validate_crc: bool=True):
    start = pos
    n, pos = read_varuint_from(mm, pos)
    fields = []
    for _ in range(n):
        key, pos = read_varuint_from(mm, pos)
        flen = key & 7
        field_no = key >> 3
        if flen == 7:
            vlen, pos = read_varuint_from(mm, pos)
        else:
            vlen = flen
        if pos+vlen > size: raise ValueError("Varstruct value exceeds file size")
        val = bytes(mm[pos:pos+vlen]); pos += vlen
        fields.append((field_no, val))
    if pos + 4 > size: raise ValueError("Varstruct truncated before CRC")
    crc_read = struct.unpack('<I', mm[pos:pos+4])[0]
    if validate_crc:
        crc_calc = crc32_ieee(bytes(mm[start:pos]))
        if crc_calc != crc_read:
            raise ValueError(f"CRC mismatch: calc=0x{crc_calc:08X} read=0x{crc_read:08X} at 0x{start:X}")
    pos += 4
    return fields, pos

def _read_varstruct(mm, pos, size, *, validate_crc: bool=True):
    want_crc = validate_crc and (CRC_MODE == "strict")
    try:
        return _read_varstruct_raw(mm, pos, size, validate_crc=want_crc)
    except Exception as e:
        if "CRC mismatch" in str(e) and CRC_MODE in ("warn","off"):
            return _read_varstruct_raw(mm, pos, size, validate_crc=False)
        raise

@dataclass
class RSDRecord:
    offset:int
    channel_id:Optional[int]
    sequence_count:int
    data_size:int
    rec_time_ms:int
    lat_deg:Optional[float]
    lon_deg:Optional[float]
    water_temp_c:Optional[float]
    bottom_depth_m:Optional[float]
    sample_cnt:Optional[int]
    sonar_data_offset:Optional[int]
    sonar_data_size:Optional[int]
    first_sample_depth_m:Optional[float]
    last_sample_depth_m:Optional[float]

class RSDParser:
    MAGIC_REC_HDR=0xB7E9DA86; MAGIC_REC_TRL=0xF98EACBC; HEADER_AREA_END=0x5000
    @staticmethod
    def mapunit_to_deg(x:int)->float: return x * (360.0 / float(1<<32))
    def __init__(self, path):
        self.path=path; self.size=os.path.getsize(path); self.header_items=[]
    def __enter__(self):
        self.f=open(self.path,'rb'); self.mm=mmap.mmap(self.f.fileno(),0,access=mmap.ACCESS_READ)
        if PARSE_HEADER:
            self.header_items = self.parse_header_area()
        return self
    def __exit__(self, a,b,c):
        try:self.mm.close()
        finally:self.f.close()
    def parse_header_area(self):
        mv = memoryview(self.mm)
        pos = 0; items=[]
        while pos < self.HEADER_AREA_END:
            try:
                fields, new_pos = _read_varstruct(mv, pos, self.size)
            except Exception:
                break
            items.append((pos, fields))
            if new_pos <= pos: break
            pos = new_pos
        logging.info("Header items parsed: %d", len(items))
        return items
    def _resync(self, start):
        end = min(len(self.mm), start + int(MAX_RESYNC_BYTES))
        magic = struct.pack('<I', self.MAGIC_REC_HDR)
        idx = self.mm.find(magic, start+1, end)
        return idx if idx != -1 else end
    def parse_records(self, max_records=None):
        mv = memoryview(self.mm)
        pos = self.HEADER_AREA_END
        seen = 0
        while pos + 12 <= self.size:
            rec_start = pos
            try:
                fields, pos_after_hdr = _read_varstruct(mv, pos, self.size)
                magic=seq=data_size=rec_time_ms=None
                for fn,val in fields:
                    if fn==0 and len(val)==4: magic=struct.unpack('<I', val)[0]
                    elif fn==2 and len(val)==4: seq=struct.unpack('<I', val)[0]
                    elif fn==4 and len(val)==2: data_size=struct.unpack('<H', val)[0]
                    elif fn==5 and len(val)==4: rec_time_ms=struct.unpack('<I', val)[0]
                if magic != self.MAGIC_REC_HDR: raise ValueError("bad magic")
                body_start = pos_after_hdr
                channel_id=lat=lon=wt=bd=sc=fsd=lsd=None
                sonar_ofs=sonar_size=None
                if data_size and data_size>0:
                    b_fields, body_end = _read_varstruct(mv, body_start, self.size)
                    def _dec_varint(b):
                        v=0;shift=0
                        for bb in b:
                            v |= (bb & 0x7F) << shift
                            if not (bb & 0x80): break
                            shift+=7
                        return v
                    for fn,val in b_fields:
                        if fn==0: channel_id=int(_dec_varint(val))
                        elif fn==1: bd = zigzag_to_int32(_dec_varint(val))/1000.0
                        elif fn==3: fsd = zigzag_to_int32(_dec_varint(val))/1000.0
                        elif fn==4: lsd = zigzag_to_int32(_dec_varint(val))/1000.0
                        elif fn==7 and len(val)==4: sc = struct.unpack('<I', val)[0]
                        elif fn==9 and len(val)==4: lat = self.mapunit_to_deg(struct.unpack('<i', val)[0])
                        elif fn==10 and len(val)==4: lon = self.mapunit_to_deg(struct.unpack('<i', val)[0])
                        elif fn==11 and len(val)==4: wt = struct.unpack('<f', val)[0]
                    used = body_end - body_start
                    sonar_ofs = body_end
                    sonar_size = max(0, (data_size or 0) - used)
                    pos = body_start + (data_size or 0)
                else:
                    pos = body_start
                if pos + 12 > self.size: break
                tr_magic, chunk_size, _ = struct.unpack('<III', self.mm[pos:pos+12])
                if tr_magic != self.MAGIC_REC_TRL or chunk_size <= 0:
                    raise ValueError("bad trailer")
                yield RSDRecord(rec_start, channel_id, seq or 0, data_size or 0, rec_time_ms or 0,
                                lat, lon, wt, bd, sc, sonar_ofs, sonar_size, fsd, lsd)
                pos = rec_start + chunk_size
                seen += 1
                if max_records and seen >= max_records: break
            except Exception:
                pos = self._resync(rec_start)
                if pos >= self.size: break

@njit(cache=True)
def _tone_map_jit(a, inv, lo, hi, gamma):
    if inv:
        for i in range(a.size): a[i] = 255.0 - a[i]
    rng = hi - lo
    if rng <= 0: rng = 1.0
    for i in range(a.size):
        v = (a[i] - lo) / rng
        if gamma != 1.0: v = v ** gamma
        v = 0.0 if v < 0.0 else (1.0 if v > 1.0 else v)
        a[i] = 255.0 * v
    return a

def tone_map(u8, invert=True, lo_pct=1.0, hi_pct=99.0, gamma=1.0):
    a=u8.astype(np.float32)
    lo=np.percentile(a, lo_pct) if 0 <= lo_pct < 50 else a.min()
    hi=np.percentile(a, hi_pct) if 50 < hi_pct <= 100 else a.max()
    if USE_NUMBA:
        out = _tone_map_jit(a.copy(), 1 if invert else 0, lo, hi, gamma)
        return np.clip(out,0,255).astype(np.uint8)
    else:
        if invert: a=255.0 - a
        if hi<=lo: hi=lo+1.0
        a=(a-lo)/(hi-lo)
        if gamma!=1.0: a = np.power(np.clip(a,0,1),gamma)
        return np.clip(a*255.0,0,255).astype(np.uint8)

def make_palette(name:str):
    x = np.linspace(0,1,256)
    if name=="amber":
        r=np.clip(3.0*x,0,1); g=np.clip(1.8*x,0,1); b=np.clip(0.5*x,0,1)
    elif name=="blue":
        r=np.clip(0.4*x,0,1); g=np.clip(0.7*x,0,1); b=np.clip(1.8*x,0,1)
    elif name=="green":
        r=np.clip(0.5*x,0,1); g=np.clip(1.8*x,0,1); b=np.clip(0.5*x,0,1)
    elif name=="ironbow":
        r=np.clip(1.5*x,0,1); g=np.clip(1.5*np.maximum(x-0.33,0),0,1); b=np.clip(1.5*np.maximum(x-0.66,0),0,1)
    else:
        r=g=b=x
    return (np.stack([r,g,b],1)*255.0 + 0.5).astype(np.uint8)

def apply_palette(u8row, lut):
    if u8row.ndim==1: u8row=u8row[np.newaxis,:]
    return lut[u8row]

def slant_resample_half(row_u8, first_sd_m, last_sd_m):
    if first_sd_m is None or last_sd_m is None: return row_u8
    sc=row_u8.size
    d = np.linspace(max(0.0, first_sd_m), max(first_sd_m, last_sd_m), sc)
    s = np.linspace(d[0], d[-1] + (d[-1]-d[0]) * 0.25, sc)
    x = np.sqrt(np.maximum(s*s - np.maximum(d,1e-3)**2, 0.0))
    x_norm = (x - x.min()) / max(1e-6, (x.max()-x.min()))
    xi = np.linspace(0,1,sc)
    idx = np.clip((np.interp(xi, x_norm, np.arange(sc))).round().astype(int), 0, sc-1)
    return row_u8[idx]

def infer_layout(blob_len, sample_cnt):
    sc=int(sample_cnt or 0)
    if sc>0:
        if blob_len == sc: return ('u8',1)
        if blob_len == 2*sc: return ('u8',2)
        if blob_len == 4*sc: return ('u16',2)
        if blob_len == 2*sc: return ('u16',1)
        ratio = blob_len / sc
        if abs(ratio-2.0)<0.06: return ('u8',2)
        if abs(ratio-1.0)<0.1: return ('u8',1)
        if abs(ratio-4.0)<0.2: return ('u16',2)
        if abs(ratio-2.0)<0.2: return ('u16',1)
    return ('u8',2)

def segment_quad(latA, lonA, latB, lonB, half_width_m):
    dN = (latB - latA) * (math.pi/180.0) * EARTH_R
    dE = (lonB - lonA) * (math.pi/180.0) * EARTH_R * math.cos(math.radians((latA+latB)/2.0))
    L  = math.hypot(dE, dN)
    if L == 0: dE, dN = 1.0, 0.0; L = 1.0
    uE, uN = dE/L, dN/L
    pE, pN = -uN, uE
    A_left  = offset_latlon(latA, lonA,  pE*half_width_m,  pN*half_width_m)
    A_right = offset_latlon(latA, lonA, -pE*half_width_m, -pN*half_width_m)
    B_left  = offset_latlon(latB, lonB,  pE*half_width_m,  pN*half_width_m)
    B_right = offset_latlon(latB, lonB, -pE*half_width_m, -pN*half_width_m)
    return [(A_left[1],A_left[0]), (A_right[1],A_right[0]), (B_right[1],B_right[0]), (B_left[1],B_left[0])]

# --- robust preview helpers (uniform width) ---
def _pad_to_width(arr, target_w, pad_value=0):
    if arr.ndim == 2:
        h, w = arr.shape
        if w >= target_w: return arr[:, :target_w]
        return np.pad(arr, ((0,0),(0,target_w-w)), mode='constant', constant_values=pad_value)
    else:
        h, w, c = arr.shape
        if w >= target_w: return arr[:, :target_w, :]
        return np.pad(arr, ((0,0),(0,target_w-w),(0,0)), mode='constant', constant_values=pad_value)

def _stack_rows_uniform(rows, pad_value=0, target_w=None):
    if not rows: return None
    max_w = max(r.shape[1] for r in rows) if target_w is None else target_w
    fixed = [_pad_to_width(r, max_w, pad_value) for r in rows]
    return np.vstack(fixed)

def build_preview_from_pngs(out_dir, base, preview_max=2000, palette_suffix=None):
    rows = []
    for fname in sorted(os.listdir(out_dir)):
        if fname.startswith(f"{base}_row_") and fname.endswith(".png"):
            if palette_suffix:
                if not fname.endswith(f"{palette_suffix}.png"): continue
            else:
                if fname.count("_") != 2:  # crude filter to avoid suffixed palette files
                    continue
            rows.append(np.array(Image.open(os.path.join(out_dir, fname))))
            if len(rows) >= preview_max: break
    if not rows: return None
    stacked = _stack_rows_uniform(rows, pad_value=0)
    mode = "RGB" if stacked.ndim == 3 else "L"
    out_path = os.path.join(out_dir, f"{base}_waterfall{palette_suffix or ''}.png")
    Image.fromarray(stacked, mode=mode).save(out_path)
    return out_path

def build_rows_and_assets(rsd_path, out_dir, cfg):
    global CRC_MODE, MAX_RESYNC_BYTES, PARSE_HEADER, USE_NUMBA, THREADS
    CRC_MODE = cfg.get("CRC_MODE", CRC_MODE)
    MAX_RESYNC_BYTES = int(cfg.get("MAX_RESYNC_BYTES", MAX_RESYNC_BYTES))
    PARSE_HEADER = bool(cfg.get("PARSE_HEADER", PARSE_HEADER))
    USE_NUMBA = bool(cfg.get("USE_NUMBA", USE_NUMBA))
    THREADS = int(cfg.get("THREADS", THREADS))

    os.makedirs(out_dir, exist_ok=True)
    ROW_H = int(cfg.get("ROW_HEIGHT_PX", 40))
    WATER_PX = int(cfg.get("WATER_COLUMN_PX", 8))
    INVERT = bool(cfg.get("INVERT", True))
    CL = float(cfg.get("CLIP_LOW_PCT", 1.0))
    CH = float(cfg.get("CLIP_HIGH_PCT", 99.0))
    GM = float(cfg.get("GAMMA", 1.0))
    PALETTES = list(cfg.get("PALETTES", ["amber"]))
    APPLY_SLANT = bool(cfg.get("APPLY_SLANT", True))
    STRIDE = int(cfg.get("STRIDE", 4))
    SWATH_SS = float(cfg.get("SWATH_M_SS", 40.0))
    MAKE_BUCKETED = bool(cfg.get("MAKE_BUCKETED_KMZ", True))
    MAKE_REGION = bool(cfg.get("MAKE_REGIONATED_KMZ", True))
    MAKE_DEPTH_GPS = bool(cfg.get("MAKE_DEPTH_GPS", True))
    GPS_STEP_M = float(cfg.get("GPS_STEP_M", 100.0))
    DEPTH_EVERY = int(cfg.get("DEPTH_EVERY_PINGS", 20))
    DEP_FT_THRESHOLD = float(cfg.get("DEP_FT_THRESHOLD", 3.0))
    PCT_CHANGE_MIN = cfg.get("PCT_CHANGE_MIN", None)
    if isinstance(PCT_CHANGE_MIN, str) and PCT_CHANGE_MIN.strip()=="": PCT_CHANGE_MIN=None
    if PCT_CHANGE_MIN is not None: PCT_CHANGE_MIN = float(PCT_CHANGE_MIN)
    DEP_M_THRESHOLD = DEP_FT_THRESHOLD * 0.3048
    PREVIEW_MAX = int(cfg.get("PREVIEW_MAX_ROWS", 2000))
    MAKE_VIDEO = bool(cfg.get("MAKE_VIDEO", True))
    VIDEO_FPS = int(cfg.get("VIDEO_FPS", 30))
    VIDEO_HEIGHT = int(cfg.get("VIDEO_HEIGHT", 1080))
    VIDEO_MAX_FRAMES = int(cfg.get("VIDEO_MAX_FRAMES", 20000))

    base = os.path.splitext(os.path.basename(rsd_path))[0]

    strip_paths=[]; latlons=[]; depths=[]; preview_rows=[]
    def process_one(idx, r, fpath):
        if r.sonar_data_offset is None or (r.sonar_data_size or 0) <= 0:
            return None
        with open(fpath, 'rb') as f:
            f.seek(r.sonar_data_offset); blob=f.read(r.sonar_data_size)
        dtype,chans = infer_layout(len(blob), r.sample_cnt)
        a=np.frombuffer(blob, dtype=np.uint8 if dtype=='u8' else '<u2')
        if dtype!='u8':
            a=(a.astype(np.float32)*(255.0/65535.0)).clip(0,255).astype(np.uint8)
        sc=int(r.sample_cnt or 0)
        if sc<=0: sc=a.size//max(1,chans)
        if chans>=2 and a.size >= 2*sc:
            port=a[:sc][::-1]; stbd=a[sc:2*sc]
        else:
            half=a.size//2; port=a[:half][::-1]; stbd=a[half:half+half]
        if APPLY_SLANT:
            port=slant_resample_half(port, r.first_sample_depth_m, r.last_sample_depth_m)
            stbd=slant_resample_half(stbd, r.first_sample_depth_m, r.last_sample_depth_m)
        scan=np.hstack([port, np.zeros(WATER_PX, dtype=np.uint8), stbd])
        g=tone_map(scan, INVERT, CL, CH, GM)
        img = Image.fromarray(g[np.newaxis,:],'L').resize((g.shape[0], ROW_H))
        png = f"{base}_row_{idx:06d}.png"; img.save(os.path.join(out_dir, png))
        return (png, (r.lon_deg, r.lat_deg), r.bottom_depth_m if r.bottom_depth_m is not None else 0.0)

    with RSDParser(rsd_path) as P:
        recs = []
        for i, r in enumerate(P.parse_records()):
            if (i % STRIDE) != 0: continue
            recs.append((i, r))
        with ThreadPoolExecutor(max_workers=max(1, THREADS)) as ex:
            futs = [ex.submit(process_one, idx, r, rsd_path) for (idx, r) in recs]
            for i, fut in enumerate(as_completed(futs)):
                out = fut.result()
                if out is None: continue
                png, ll, d = out
                strip_paths.append(png); latlons.append(ll); depths.append(d)

    # robust preview from PNGs (uniform widths)
    _ = build_preview_from_pngs(out_dir, base, preview_max=PREVIEW_MAX, palette_suffix=None)

    # Make palette copies and optional palette previews
    for pal in PALETTES:
        lut = make_palette(pal)
        for png in strip_paths:
            arr = np.array(Image.open(os.path.join(out_dir, png)))
            # arr shape is (ROW_H, W) because grayscale saved with height first; get intensity row:
            if arr.ndim == 3:  # handle RGB accidentally
                gray = arr[:, :, 0]
            else:
                gray = arr[:, :]
            # take a single pixel row as intensity (they are resized vertically)
            # safer: reduce vertically (mean)
            if gray.ndim == 2:
                gray1 = gray.mean(axis=0).astype(np.uint8)
            else:
                gray1 = gray.astype(np.uint8)
            rgbrow = lut[gray1]
            rgbimg = Image.fromarray(np.tile(rgbrow[np.newaxis, :, :], (arr.shape[0], 1, 1)).astype(np.uint8), 'RGB')
            outp = os.path.join(out_dir, png.replace(".png", f"_{pal}.png"))
            rgbimg.save(outp)
        # palette preview
        build_preview_from_pngs(out_dir, base, preview_max=PREVIEW_MAX, palette_suffix=f"_{pal}")

    # KMLs
    import simplekml, zipfile
    if MAKE_DEPTH_GPS:
        k = simplekml.Kml()
        ls = k.newlinestring(name=f"{base} track")
        coords=[(lon,lat,0) for lon,lat in latlons if None not in (lon,lat)]
        ls.coords = coords
        k.save(os.path.join(out_dir, f"{base}_track.kml"))
        kd = simplekml.Kml(); fd=kd.newfolder(name="Depth pings")
        for idx, ((lon,lat), d) in enumerate(zip(latlons, depths)):
            if None in (lon,lat): continue
            if idx % max(1, DEPTH_EVERY) == 0:
                fd.newpoint(name=f"{d:.1f} m", coords=[(lon,lat,0)])
        kd.save(os.path.join(out_dir, f"{base}_depth_every.kml"))
        kc = simplekml.Kml(); fc=kc.newfolder(name="Depth change")
        prev=None
        for (lon,lat), d in zip(latlons, depths):
            if None in (lon,lat) or d is None: continue
            fire=False; label=None
            if prev is not None:
                if abs(d - prev) >= DEP_M_THRESHOLD:
                    fire=True; label=f"Δdepth {d:.1f} m (> {DEP_FT_THRESHOLD:.1f} ft)"
                if PCT_CHANGE_MIN is not None and prev>0:
                    pct = 100.0*abs(d-prev)/prev
                    if pct >= PCT_CHANGE_MIN:
                        fire=True; label=f"Δdepth {d:.1f} m ({pct:.1f}%)"
            if fire:
                fc.newpoint(name=label or f"{d:.1f} m", coords=[(lon,lat,0)])
            prev = d
        kc.save(os.path.join(out_dir, f"{base}_depth_change.kml"))

    def write_bucketed_kmz(pal):
        images_dir_in_kmz="files"
        kmz_path = os.path.join(out_dir, f"{base}_sidescan_bucketed_{pal}.kmz")
        kml = ['<?xml version="1.0" encoding="UTF-8"?>','<kml xmlns="http://www.opengis.net/kml/2.2" xmlns:gx="http://www.google.com/kml/ext/2.2">','<Document>',
               f'<name>{base} sidescan (bucketed {pal})</name>']
        used=[]
        for i in range(0, len(strip_paths)-1):
            img = strip_paths[i].replace(".png", f"_{pal}.png")
            lonA,latA = latlons[i]
            lonB,latB = latlons[i+1] if i+1 < len(latlons) else latlons[i]
            if None in (lonA,latA,lonB,latB): continue
            quad = segment_quad(latA, lonA, latB, lonB, SWATH_SS)
            coords_txt = " ".join([f"{lon:.8f},{lat:.8f}" for lon,lat in quad])
            kml += ['<GroundOverlay>',
                    f'  <name>{img}</name>',
                    '  <Icon>',
                    f'    <href>{images_dir_in_kmz}/{img}</href>',
                    '  </Icon>',
                    '  <gx:LatLonQuad>',
                    f'    <coordinates>{coords_txt}</coordinates>',
                    '  </gx:LatLonQuad>',
                    '</GroundOverlay>']
            used.append(img)
        kml += ['</Document>','</kml>']
        with zipfile.ZipFile(kmz_path, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
            zf.writestr("doc.kml", "\n".join(kml))
            for img in used:
                zf.write(os.path.join(out_dir, img), f"{images_dir_in_kmz}/{img}")
        return kmz_path

    def write_regionated_kmz(pal):
        images_dir_in_kmz="files"
        kmz_path = os.path.join(out_dir, f"{base}_sidescan_regionated_{pal}.kmz")
        valids=[(lon,lat) for lon,lat in latlons if None not in (lon,lat)]
        if not valids: return None
        lons=[a for a,b in valids]; lats=[b for a,b in valids]
        lat_min,lat_max=min(lats),max(lats); lon_min,lon_max=min(lons),max(lons)
        mid_lat=(lat_min+lat_max)/2.0; mid_lon=(lon_min+lon_max)/2.0
        quads={"NW":(mid_lat,lat_max,lon_min,mid_lon),"NE":(mid_lat,lat_max,mid_lon,lon_max),
               "SW":(lat_min,mid_lat,lon_min,mid_lon),"SE":(lat_min,mid_lat,mid_lon,lon_max)}
        buckets={k:[] for k in quads}
        for idx,(lon,lat) in enumerate(latlons[:-1]):
            if None in (lon,lat): continue
            key=("N" if lat>=mid_lat else "S")+("W" if lon<mid_lon else "E")
            buckets[key].append(idx)
        def region_folder(name, lat_min, lat_max, lon_min, lon_max):
            return [f'<Folder><name>{name}</name>','<Region>',
                    f'<LatLonAltBox><north>{lat_max:.8f}</north><south>{lat_min:.8f}</south><east>{lon_max:.8f}</east><west>{lon_min:.8f}</west></LatLonAltBox>',
                    '<Lod><minLodPixels>64</minLodPixels><maxLodPixels>-1</maxLodPixels></Lod>','</Region>']
        kml=['<?xml version="1.0" encoding="UTF-8"?>','<kml xmlns="http://www.opengis.net/kml/2.2" xmlns:gx="http://www.google.com/kml/ext/2.2">','<Document>',
             f'<name>{base} sidescan (regionated {pal})</name>']
        for name,(sN,nN,wE,eE) in quads.items():
            kml += region_folder(name, sN,nN,wE,eE)
            for idx in buckets[name]:
                img = strip_paths[idx].replace(".png", f"_{pal}.png")
                lonA,latA = latlons[idx]
                lonB,latB = latlons[idx+1] if idx+1 < len(latlons) else latlons[idx]
                if None in (lonA,latA,lonB,latB): continue
                quad = segment_quad(latA, lonA, latB, lonB, SWATH_SS)
                coords_txt = " ".join([f"{lon:.8f},{lat:.8f}" for lon,lat in quad])
                kml += ['<GroundOverlay>',
                        f'  <name>{img}</name>',
                        '  <Icon>',
                        f'    <href>{images_dir_in_kmz}/{img}</href>',
                        '  </Icon>',
                        '  <gx:LatLonQuad>',
                        f'    <coordinates>{coords_txt}</coordinates>',
                        '  </gx:LatLonQuad>',
                        '</GroundOverlay>']
            kml += ['</Folder>']
        kml += ['</Document>','</kml>']
        with zipfile.ZipFile(kmz_path, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
            zf.writestr("doc.kml", "\n".join(kml))
            for img in strip_paths:
                img2 = img.replace(".png", f"_{pal}.png")
                zf.write(os.path.join(out_dir, img2), f"{images_dir_in_kmz}/{img2}")
        return kmz_path

    # write KMZs for first selected palette
    if PALETTES:
        pal0 = PALETTES[0]
        if MAKE_BUCKETED: write_bucketed_kmz(pal0)
        if MAKE_REGION:   write_regionated_kmz(pal0)

    # Optional video (pad to multiples of 16 and set macro_block_size=1)
    if MAKE_VIDEO:
        try:
            import imageio.v2 as imageio
            mp4_path = os.path.join(out_dir, f"{base}_waterfall.mp4")
            rows_cache=[]; step=1; writer=None
            # build a tall frame by stacking last N rows
            # pick target width = max strip width, ensure multiple of 16
            widths=[]
            for png in strip_paths[:200]:
                arr=np.array(Image.open(os.path.join(out_dir, png)))
                widths.append(arr.shape[1])
            target_w = max(widths) if widths else 2048
            target_w = ((target_w + 15)//16)*16
            row_h = int(cfg.get("ROW_HEIGHT_PX", 40))
            rows_needed = max(1, int(cfg.get("VIDEO_HEIGHT", 1080)) // row_h)
            writer = imageio.get_writer(mp4_path, fps=int(cfg.get("VIDEO_FPS", 30)),
                                        codec='libx264', quality=8, macro_block_size=1)
            for i, png in enumerate(sorted(strip_paths)):
                arr=np.array(Image.open(os.path.join(out_dir, png)))
                # pad/crop each row to target_w and ensure RGB
                if arr.ndim==2:
                    arr = np.stack([arr,arr,arr], axis=-1)
                if arr.shape[1] != target_w:
                    pad = np.zeros((arr.shape[0], target_w, 3), dtype=arr.dtype)
                    w = min(arr.shape[1], target_w)
                    pad[:, :w, :] = arr[:, :w, :]
                    arr = pad
                rows_cache.append(arr)
                if len(rows_cache) > rows_needed: rows_cache.pop(0)
                if len(rows_cache) == rows_needed:
                    frame = np.vstack(rows_cache)
                    # ensure height multiple of 16
                    H, W = frame.shape[:2]
                    H16 = ((H + 15)//16)*16
                    if H != H16:
                        pad = np.zeros((H16, W, 3), dtype=frame.dtype)
                        pad[:H, :W, :] = frame
                        frame = pad
                    writer.append_data(frame)
                    if (i+1) >= int(cfg.get("VIDEO_MAX_FRAMES", 20000)):
                        break
            if writer is not None: writer.close()
        except Exception as e:
            logging.warning("Video generation skipped: %s", e)

    return dict(rows=len(strip_paths), out_dir=out_dir, palettes=PALETTES, crc_mode=CRC_MODE, threads=THREADS)
