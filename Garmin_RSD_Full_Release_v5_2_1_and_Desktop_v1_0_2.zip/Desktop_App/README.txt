Garmin RSD Desktop App v1.0.2 (Patched, Standalone Core)
====================================================
Run:
  - Windows/Mac/Linux: python app.py
  - (Optional) create venv first; install deps: pip install -r requirements.txt

Build one-file EXE (Windows) with PyInstaller:
  pyinstaller --onefile --noconsole --name GarminRSD app.py

macOS app (basic):
  pyinstaller --onefile --windowed --name GarminRSD app.py

Notes:
  - GUI exposes CRC mode, resync window, header parse, Numba toggle, threads,
    rendering knobs, depth/GPS markers, bucketed & regionated KMZs, and video.
  - Core includes robust preview (uniform widths) and MP4 writer with macro_block_size=1 + padding.
