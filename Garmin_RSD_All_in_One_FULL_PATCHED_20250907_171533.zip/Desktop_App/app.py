#!/usr/bin/env python3
import os, sys, threading, queue, webbrowser, json
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

HERE = Path(__file__).resolve().parent
CORE_PATH = HERE / "rsd_core_crc_plus.py"
import importlib.util
spec = importlib.util.spec_from_file_location("rsd_core_crc_plus", str(CORE_PATH))
core = importlib.util.module_from_spec(spec); spec.loader.exec_module(core)

APP_NAME="Garmin RSD Desktop"; APP_VER="1.2.5"
CFG_DIR=Path.home()/".garmin_rsd_gui"; CFG_DIR.mkdir(parents=True, exist_ok=True)
RECENT_PATH=CFG_DIR/"recent.json"

def save_recent(rsd,out_parent,run_name):
    try: RECENT_PATH.write_text(json.dumps({'rsd':rsd,'out_parent':out_parent,'run_name':run_name}, indent=2))
    except Exception: pass

def load_recent():
    try:
        obj=json.loads(RECENT_PATH.read_text())
        if isinstance(obj,dict): return obj
        if isinstance(obj,list) and obj and isinstance(obj[0],dict): return obj[0]
    except Exception: pass
    return {}

class App(tk.Tk):
    def __init__(self):
        super().__init__(); self.title(f"{APP_NAME} — {APP_VER}"); self.geometry("900x640"); self.minsize(880,560)
        self.q=queue.Queue(); self.cancel_flag=False; self.out_dir=None
        self._build(); self._load_recent(); self.after(120, self._pump)
    def _build(self):
        pad={'padx':8,'pady':6}; frm=ttk.Frame(self); frm.pack(fill="both", expand=True)
        self.rsd=tk.StringVar(); ttk.Label(frm,text="RSD file:").grid(row=0,column=0,sticky="w",**pad)
        ttk.Entry(frm,textvariable=self.rsd,width=70).grid(row=0,column=1,sticky="we",**pad)
        ttk.Button(frm,text="Browse…",command=self._pick_rsd).grid(row=0,column=2,**pad)
        self.outp=tk.StringVar(value=str(Path.home()/ "Garmin_RSD_Runs"))
        self.run=tk.StringVar(value="run_desktop")
        ttk.Label(frm,text="Output parent:").grid(row=1,column=0,sticky="w",**pad)
        ttk.Entry(frm,textvariable=self.outp,width=50).grid(row=1,column=1,sticky="we",**pad)
        ttk.Button(frm,text="Browse…",command=self._pick_out).grid(row=1,column=2,**pad)
        ttk.Label(frm,text="Run name:").grid(row=2,column=0,sticky="w",**pad); ttk.Entry(frm,textvariable=self.run,width=30).grid(row=2,column=1,sticky="w",**pad)
        ttk.Separator(frm).grid(row=3,column=0,columnspan=3, sticky="we", padx=6, pady=4)
        opts=ttk.Labelframe(frm,text="Options"); opts.grid(row=4,column=0,columnspan=3, sticky="we", padx=8)
        self.crc=tk.StringVar(value="warn"); self.rh=tk.IntVar(value=40); self.gap=tk.IntVar(value=8)
        self.inv=tk.BooleanVar(value=True); self.cl=tk.DoubleVar(value=0.2); self.ch=tk.DoubleVar(value=99.8); self.ga=tk.DoubleVar(value=0.9)
        self.stride=tk.IntVar(value=1); self.swath=tk.DoubleVar(value=45.0)
        self.mkvid=tk.BooleanVar(value=True); self.vfps=tk.IntVar(value=30); self.vh=tk.IntVar(value=1080); self.vmax=tk.IntVar(value=20000)
        ttk.Label(opts,text="CRC mode").grid(row=0,column=0,sticky="w"); ttk.Combobox(opts,textvariable=self.crc,values=["strict","warn","off"],width=10).grid(row=0,column=1,sticky="w")
        ttk.Label(opts,text="Row height").grid(row=1,column=0,sticky="w"); ttk.Spinbox(opts,from_=10,to=200,increment=2,textvariable=self.rh,width=8).grid(row=1,column=1,sticky="w")
        ttk.Label(opts,text="Water gap px").grid(row=2,column=0,sticky="w"); ttk.Spinbox(opts,from_=0,to=64,textvariable=self.gap,width=8).grid(row=2,column=1,sticky="w")
        ttk.Checkbutton(opts,text="Invert",variable=self.inv).grid(row=3,column=0,sticky="w")
        ttk.Label(opts,text="Clip low %").grid(row=4,column=0,sticky="w"); ttk.Spinbox(opts,from_=0.0,to=10.0,increment=0.1,textvariable=self.cl,width=8).grid(row=4,column=1,sticky="w")
        ttk.Label(opts,text="Clip high %").grid(row=5,column=0,sticky="w"); ttk.Spinbox(opts,from_=50.0,to=100.0,increment=0.1,textvariable=self.ch,width=8).grid(row=5,column=1,sticky="w")
        ttk.Label(opts,text="Gamma").grid(row=6,column=0,sticky="w"); ttk.Spinbox(opts,from_=0.1,to=3.0,increment=0.1,textvariable=self.ga,width=8).grid(row=6,column=1,sticky="w")
        ttk.Label(opts,text="Stride").grid(row=7,column=0,sticky="w"); ttk.Spinbox(opts,from_=1,to=16,textvariable=self.stride,width=8).grid(row=7,column=1,sticky="w")
        ttk.Label(opts,text="SS swath (m)").grid(row=8,column=0,sticky="w"); ttk.Spinbox(opts,from_=5.0,to=150.0,increment=1.0,textvariable=self.swath,width=8).grid(row=8,column=1,sticky="w")
        ttk.Checkbutton(opts,text="Make MP4",variable=self.mkvid).grid(row=9,column=0,sticky="w")
        ttk.Label(opts,text="Video FPS").grid(row=10,column=0,sticky="w"); ttk.Spinbox(opts,from_=1,to=60,textvariable=self.vfps,width=8).grid(row=10,column=1,sticky="w")
        ttk.Label(opts,text="Video height").grid(row=11,column=0,sticky="w"); ttk.Spinbox(opts,from_=256,to=2160,increment=16,textvariable=self.vh,width=8).grid(row=11,column=1,sticky="w")
        ttk.Label(opts,text="Max frames").grid(row=12,column=0,sticky="w"); ttk.Spinbox(opts,from_=100,to=100000,increment=100,textvariable=self.vmax,width=8).grid(row=12,column=1,sticky="w")
        btns=ttk.Frame(frm); btns.grid(row=5,column=0,columnspan=3, sticky="we", padx=8, pady=4)
        self.run_btn=ttk.Button(btns,text="Run ▶",command=self._run); self.run_btn.pack(side="left",padx=6)
        self.cancel_btn=ttk.Button(btns,text="Cancel",command=self._cancel,state="disabled"); self.cancel_btn.pack(side="left",padx=6)
        self.open_btn=ttk.Button(btns,text="Open output folder",command=self._open_out,state="disabled"); self.open_btn.pack(side="right",padx=6)
        self.pb=ttk.Progressbar(frm,orient="horizontal",mode="determinate",maximum=100.0); self.pb.grid(row=6,column=0,columnspan=3, sticky="we", padx=8, pady=4)
        self.log=tk.Text(frm,height=12); self.log.grid(row=7,column=0,columnspan=3, sticky="nsew", padx=8, pady=6)
        frm.rowconfigure(7,weight=1); frm.columnconfigure(1,weight=1)
    def _pick_rsd(self):
        p=filedialog.askopenfilename(title="Select Garmin .RSD", filetypes=[("Garmin RSD","*.RSD"),("All files","*.*")])
        if p: self.rsd.set(p)
    def _pick_out(self):
        d=filedialog.askdirectory(title="Select output parent folder")
        if d: self.outp.set(d)
    def _open_out(self):
        if self.out_dir and Path(self.out_dir).exists():
            try: os.startfile(self.out_dir)
            except Exception: 
                import webbrowser; webbrowser.open(self.out_dir)
    def _log(self,msg): self.log.insert("end", msg+"\n"); self.log.see("end")
    def _on_progress(self,pct,msg): self.q.put(("progress", float(pct), str(msg)))
    def _pump(self):
        try:
            while True:
                kind,*rest=self.q.get_nowait()
                if kind=="progress": pct,msg=rest; self.pb['value']=pct; self._log(msg)
                elif kind=="done":
                    ok,out_dir,rows=rest; self.run_btn['state']='normal'; self.cancel_btn['state']='disabled'; self.open_btn['state']='normal' if ok else 'disabled'
                    if ok: self._log(f"Done. Rows: {rows} Out: {out_dir}"); self.out_dir=out_dir
                elif kind=="error":
                    self.run_btn['state']='normal'; self.cancel_btn['state']='disabled'; self._log('ERROR: '+rest[0])
        except Exception: pass
        self.after(120,self._pump)
    def _cancel(self): self.cancel_flag=True; self._log("Cancel requested…")
    def _run(self):
        rsd=self.rsd.get().strip(); outp=self.outp.get().strip(); run=self.run.get().strip() or "run_desktop"
        if not rsd or not os.path.exists(rsd): messagebox.showerror("Missing RSD","Please select a valid .RSD file."); return
        os.makedirs(outp, exist_ok=True); out_dir=os.path.join(outp, run); os.makedirs(out_dir, exist_ok=True); self.out_dir=out_dir; save_recent(rsd,outp,run)
        cfg=dict(CRC_MODE=self.crc.get(), ROW_HEIGHT_PX=int(self.rh.get()), WATER_COLUMN_PX=int(self.gap.get()), INVERT=bool(self.inv.get()),
                 CLIP_LOW_PCT=float(self.cl.get()), CLIP_HIGH_PCT=float(self.ch.get()), GAMMA=float(self.ga.get()), STRIDE=int(self.stride.get()),
                 SWATH_M_SS=float(self.swath.get()), MAKE_VIDEO=bool(self.mkvid.get()), VIDEO_FPS=int(self.vfps.get()), VIDEO_HEIGHT=int(self.vh.get()), VIDEO_MAX_FRAMES=int(self.vmax.get()))
        self.run_btn['state']='disabled'; self.cancel_btn['state']='normal'; self.pb['value']=0; self.log.delete("1.0","end"); self.cancel_flag=False
        def _bg():
            try:
                core.set_progress_hook(self._on_progress); core.set_cancel_hook(lambda: self.cancel_flag)
                summary=core.build_rows_and_assets(rsd, out_dir, cfg); self.q.put(("done", True, summary.get("out_dir"), summary.get("rows", 0)))
            except Exception as e:
                import traceback; self.q.put(("error", f"{e}\n{traceback.format_exc()}"))
        import threading; threading.Thread(target=_bg, daemon=True).start()
    def _load_recent(self):
        r=load_recent(); 
        if isinstance(r, dict):
            self.rsd.set(r.get('rsd',''))
            if r.get('out_parent'): self.outp.set(r['out_parent'])
            if r.get('run_name'): self.run.set(r['run_name'])

if __name__ == "__main__":
    App().mainloop()
