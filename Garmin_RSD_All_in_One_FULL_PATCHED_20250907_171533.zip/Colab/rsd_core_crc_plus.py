# rsd_core_crc_plus.py — advanced core pipeline (CRC, tolerant parser, rows/KMZ/MP4)
import os, io, math, mmap, struct, logging, zipfile
from dataclasses import dataclass
from typing import Optional, Tuple, List, Dict
from pathlib import Path
import numpy as np
from PIL import Image
import imageio.v2 as imageio

logging.getLogger().setLevel(logging.INFO)

# Progress / cancel hooks for GUI / notebooks
_progress_hook=None; _cancel_hook=None
def set_progress_hook(fn): 
    global _progress_hook; _progress_hook=fn
def set_cancel_hook(fn):
    global _cancel_hook; _cancel_hook=fn
def _progress(pct,msg):
    if _progress_hook:
        try: _progress_hook(float(pct), str(msg))
        except Exception: pass
def _cancelled(): 
    return bool(_cancel_hook and _cancel_hook())

# Custom CRC-32 (poly 0x04C11DB7, init=0, reflect in/out, xorout=0xFFFFFFFF)
def _crc32_custom(data: bytes) -> int:
    poly=0x04C11DB7; crc=0
    for b in data:
        crc ^= (int(b)<<24) & 0xFFFFFFFF
        for _ in range(8):
            if crc & 0x80000000: crc=((crc<<1)^poly)&0xFFFFFFFF
            else: crc=(crc<<1)&0xFFFFFFFF
    # reflect out
    rev=0; tmp=crc
    for _ in range(32): rev=(rev<<1)|(tmp&1); tmp>>=1
    return (rev ^ 0xFFFFFFFF) & 0xFFFFFFFF

def _read_varuint_from(mv,pos,limit):
    res=0; shift=0
    while pos<limit:
        b=mv[pos]; pos+=1; res|=(b&0x7F)<<shift
        if not(b&0x80): return res,pos
        shift+=7
        if shift>35: break
    raise ValueError('VarUInt overflow')
def _zigzag_to_int32(u): return (u>>1)^(-(u&1))
def _read_varint_from(mv,pos,limit):
    u,pos=_read_varuint_from(mv,pos,limit); return _zigzag_to_int32(u),pos

MAGIC_REC_HDR=0xB7E9DA86
MAGIC_REC_TRL=0xD9264B7C
HEADER_AREA_END=0x5000
EARTH_R=6371000.0

@dataclass
class RSDRecord:
    ofs:int; channel_id:Optional[int]; seq:int; time_ms:int; data_size:int
    lat:Optional[float]; lon:Optional[float]; depth_m:Optional[float]
    sample_cnt:Optional[int]; beam_angle_deg:Optional[float]
    sonar_ofs:Optional[int]; sonar_size:Optional[int]

def _scan_next_magic(mv, pos, limit, magic=MAGIC_REC_HDR, step=1, budget=8*1024*1024):
    # Scan forward up to budget bytes for the next valid record magic.
    end = min(pos + budget, limit - 4)
    mbytes = magic.to_bytes(4, "little")
    i = max(0, pos)
    while i <= end:
        if mv[i:i+4] == mbytes:
            return i
        i += step
    return -1

def _parse_varstruct(mv,pos,limit,crc_mode='warn'):
    start = pos
    n, pos = _read_varuint_from(mv, pos, limit)
    if n < 0 or n > 10000:
        raise ValueError(f'Unreasonable field count: {n}')
    fields = {}
    for _ in range(n):
        key, pos = _read_varuint_from(mv, pos, limit)
        fn = key >> 3
        lc = key & 7
        if lc == 7:
            vlen, pos = _read_varuint_from(mv, pos, limit)
            if vlen < 0 or vlen > (limit - pos):
                raise ValueError('Varstruct value exceeds file size')
        else:
            vlen = lc
        endv = pos + vlen
        if endv > limit:
            raise ValueError('Varstruct value exceeds file size')
        fields[fn] = bytes(mv[pos:endv])  # copy bytes (prevents exported pointers)
        pos = endv
    if pos + 4 > limit:
        raise ValueError('Truncated before CRC')
    crc_read = struct.unpack('<I', mv[pos:pos+4])[0]
    pos += 4
    data = bytes(mv[start:pos-4])
    crc_calc = _crc32_custom(data)
    if crc_mode == 'strict' and crc_calc != crc_read:
        raise ValueError(f'CRC mismatch: calc=0x{crc_calc:08X} read=0x{crc_read:08X}')
    elif crc_mode == 'warn' and crc_calc != crc_read:
        logging.warning('CRC mismatch at 0x%X', start)
    return fields, pos

def _mapunit_to_deg(x:int)->float: return x*(360.0/float(1<<32))

def _infer_layout(blob_len,sample_cnt):
    sc=int(sample_cnt or 0)
    if sc>0:
        ratio=blob_len/max(1,sc)
        if blob_len==sc: return ('u8',1)
        if abs(ratio-2.0)<0.15: return ('u8',2)
        if abs(ratio-4.0)<0.25: return ('u16',2)
        if abs(ratio-1.0)<0.15: return ('u8',1)
        if abs(ratio-2.0)<0.25: return ('u16',1)
    return ('u8',2)

def parse_rsd_records(path, crc_mode='warn', max_resync_bytes=8*1024*1024):
    recs=[]; size=os.path.getsize(path)
    with open(path,'rb') as f:
        mm=mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ); mv=memoryview(mm)
        pos=HEADER_AREA_END if size>=HEADER_AREA_END else 0
        while pos + 12 < size:
            rec_start = pos
            try:
                hdr, pos = _parse_varstruct(mv, pos, size, crc_mode)
            except Exception as e:
                logging.warning('Header parse error at 0x%X: %s', pos, e)
                nxt = _scan_next_magic(mv, pos, size)
                if nxt >= 0:
                    pos = nxt
                    continue
                pos = min(pos + 1, size - 1)
                if pos - rec_start > max_resync_bytes:
                    break
                continue

            magic = struct.unpack('<I', hdr.get(0, b'\x00'*4)[:4])[0]
            if magic != MAGIC_REC_HDR:
                nxt = _scan_next_magic(mv, rec_start + 1, size)
                if nxt < 0:
                    break
                pos = nxt
                continue

            seq = struct.unpack('<I', hdr.get(2, b'\x00'*4)[:4])[0]
            time_ms = struct.unpack('<I', hdr.get(5, b'\x00'*4)[:4])[0]
            data_size = struct.unpack('<H', (hdr.get(4, b'\x00'*2)[:2] or b'\x00\x00'))[0]
            body_start = pos

            try:
                body, pos = _parse_varstruct(mv, pos, size, crc_mode)
            except Exception as e:
                logging.warning('Body parse error at 0x%X: %s', pos, e)
                body = {}
                pos = body_start + max(0, data_size)

            channel_id=None; lat=None; lon=None; depth_m=None; sample_cnt=None; beam_angle=None
            if body:
                if 0 in body: channel_id = int.from_bytes(body[0][:4].ljust(4, b'\x00'), 'little')
                if 9 in body and len(body[9]) == 4: lat = _mapunit_to_deg(struct.unpack('<i', body[9])[0])
                if 10 in body and len(body[10]) == 4: lon = _mapunit_to_deg(struct.unpack('<i', body[10])[0])
                if 1 in body:
                    try:
                        v, _ = _read_varint_from(memoryview(body[1]), 0, len(body[1])); depth_m = v / 1000.0
                    except Exception:
                        pass
                if 7 in body: sample_cnt = int.from_bytes(body[7][:4].ljust(4, b'\x00'), 'little')
                if 12 in body and len(body[12]) >= 4:
                    try: beam_angle = struct.unpack('<f', body[12][:4])[0]
                    except Exception: pass

            used = pos - body_start
            sonar_ofs = pos
            sonar_size = max(0, data_size - used) if data_size > 0 else 0
            pos = body_start + data_size

            if pos + 12 > size:
                logging.warning('Truncated before trailer at 0x%X', pos)
                break
            try:
                tr_magic, chunk_size, tr_crc = struct.unpack('<III', mv[pos:pos+12])
            except Exception as e:
                logging.warning('Trailer unpack error at 0x%X: %s', pos, e)
                nxt = _scan_next_magic(mv, pos + 1, size)
                if nxt < 0: break
                pos = nxt
                continue

            if tr_magic != 0xD9264B7C or chunk_size <= 0:
                logging.warning('Trailer mismatch at 0x%X', pos)
                nxt = _scan_next_magic(mv, pos + 1, size)
                if nxt < 0:
                    pos = min(pos + 1, size - 1)
                    continue
                pos = nxt
                continue

            recs.append(RSDRecord(rec_start, channel_id, seq, time_ms, data_size, lat, lon, depth_m,
                                  sample_cnt, beam_angle, sonar_ofs, sonar_size))

            pos = rec_start + chunk_size
            if _cancelled(): break
        try:
            mv.release()
        except Exception:
            pass
        mm.close()
    return recs

def _normalize_to_u8(a,is_u16): 
    a=a.astype(np.float32)
    if is_u16: a*= (255.0/65535.0)
    return np.clip(a,0,255).astype(np.uint8)

def _tone_map(u8,invert=True,cl=0.2,ch=99.8,g=0.9):
    a=u8.astype(np.float32)
    if invert: a=255.0-a
    lo=np.percentile(a,cl) if 0<=cl<50 else a.min()
    hi=np.percentile(a,ch) if 50<ch<=100 else a.max()
    if hi<=lo: hi=lo+1.0
    a=(a-lo)/(hi-lo)
    if g!=1.0: a=np.power(np.clip(a,0,1),g)
    return np.clip(a*255.0,0,255).astype(np.uint8)

def build_rows_and_assets(rsd_path,out_dir,cfg):
    Path(out_dir).mkdir(parents=True, exist_ok=True)
    base=Path(rsd_path).stem
    CRC_MODE=cfg.get('CRC_MODE','warn'); STRIDE=max(1,int(cfg.get('STRIDE',1)))
    ROW_H=int(cfg.get('ROW_HEIGHT_PX',40)); WATER=int(cfg.get('WATER_COLUMN_PX',8))
    INVERT=bool(cfg.get('INVERT',True)); CL=float(cfg.get('CLIP_LOW_PCT',0.2))
    CH=float(cfg.get('CLIP_HIGH_PCT',99.8)); G=float(cfg.get('GAMMA',0.9))
    SWATH=float(cfg.get('SWATH_M_SS',45.0))
    MAKE_VIDEO=bool(cfg.get('MAKE_VIDEO',True)); FPS=int(cfg.get('VIDEO_FPS',30))
    VHEIGHT=int(cfg.get('VIDEO_HEIGHT',1080)); VMAX=int(cfg.get('VIDEO_MAX_FRAMES',20000))

    _progress(5,'Parsing RSD…')
    try: recs=parse_rsd_records(rsd_path, CRC_MODE)
    except Exception as e: logging.error('Parse failed: %s', e); recs=[]

    csv_path=Path(out_dir,f'{base}_records.csv')
    with open(csv_path,'w',encoding='utf-8') as fp:
        fp.write('file_ofs,channel_id,seq,time_ms,lat_deg,lon_deg,bottom_depth_m,sample_cnt,sonar_ofs,sonar_size\n')
        for r in recs:
            fp.write(f"{r.ofs},{r.channel_id or ''},{r.seq},{r.time_ms},"
                     f"{'' if r.lat is None else f'{r.lat:.8f}'},"
                     f"{'' if r.lon is None else f'{r.lon:.8f}'},"
                     f"{'' if r.depth_m is None else f'{r.depth_m:.3f}'},"
                     f"{r.sample_cnt or ''},{r.sonar_ofs or ''},{r.sonar_size or ''}\n")

    rows=[]; widths=[]
    total=max(1,len(recs[::STRIDE]))
    for i,r in enumerate(recs[::STRIDE]):
        _progress(10+(i/total)*60, f'Row {i+1}/{total}')
        if not (r.sonar_ofs and r.sonar_size and r.sonar_size>0): continue
        with open(rsd_path,'rb') as f:
            f.seek(r.sonar_ofs); blob=f.read(r.sonar_size)
        dtype,ch=_infer_layout(len(blob), r.sample_cnt)
        if dtype=='u8': a=np.frombuffer(blob, dtype=np.uint8)
        else: a=np.frombuffer(blob, dtype='<u2'); a=_normalize_to_u8(a,True)
        sc=int(r.sample_cnt or 0); 
        if sc<=0: sc=a.size//max(1,ch)
        if ch==2 and a.size>=2*sc:
            port=a[:sc]; stbd=a[sc:2*sc]
            row=np.hstack([port[::-1], np.zeros(WATER,dtype=np.uint8), stbd])
        else:
            row=a[:sc]
        row=_tone_map(row, INVERT, CL, CH, G)
        rows.append(row); widths.append(len(row))
        if _cancelled(): break

    if not rows:
        w=1024
        for i in range(120):
            x=np.linspace(0,1,w); rows.append((255*(0.5+0.5*np.sin(6.28*(x+i/20)))).astype(np.uint8)); widths.append(w)

    maxw=max(widths)
    rows = [ np.pad(r,(0,maxw-len(r)),'edge') if len(r)!=maxw else r for r in rows ]

    row_paths=[]
    for idx,row in enumerate(rows):
        img=Image.fromarray(np.stack([row,row,row],axis=1).reshape(1,maxw,3),'RGB').resize((maxw, ROW_H))
        p=Path(out_dir,f'{base}_row_{idx:06d}.png'); img.save(p); row_paths.append(p)

    if row_paths:
        prev_h=min(2000,len(row_paths))*ROW_H
        canvas=Image.new('RGB', (maxw, prev_h)); y=0
        for p in row_paths[:prev_h//ROW_H]:
            canvas.paste(Image.open(p),(0,y)); y+=ROW_H
        canvas.save(Path(out_dir,f'{base}_waterfall.png'))

    def _meters_to_deg_lat(dy): return (dy/6371000.0)*(180.0/math.pi)
    def _meters_to_deg_lon(dx,lat): return (dx/(6371000.0*math.cos(math.radians(lat))))*(180.0/math.pi)
    def _offset(lat,lon,dxE,dyN): return lat+_meters_to_deg_lat(dyN), lon+_meters_to_deg_lon(dxE,lat)

    kml=['<?xml version="1.0" encoding="UTF-8"?>','<kml xmlns="http://www.opengis.net/kml/2.2" xmlns:gx="http://www.google.com/kml/ext/2.2">','<Document>',f'<name>{base} sidescan</name>']
    used=0; images_dir='files'
    for i in range(min(len(row_paths)-1, len(recs)-1)):
        rA, rB = recs[i], recs[i+1]
        if rA.lat is None or rA.lon is None or rB.lat is None or rB.lon is None: continue
        half=float(SWATH)
        dN=(rB.lat-rA.lat)*(math.pi/180.0)*6371000.0
        dE=(rB.lon-rA.lon)*(math.pi/180.0)*6371000.0*math.cos(math.radians((rA.lat+rB.lat)/2.0))
        L=math.hypot(dE,dN); 
        if L==0: dE, dN, L = 1.0, 0.0, 1.0
        uE, uN = dE/L, dN/L; pE, pN = -uN, uE
        A_l=_offset(rA.lat,rA.lon, pE*half, pN*half)
        A_r=_offset(rA.lat,rA.lon,-pE*half,-pN*half)
        B_l=_offset(rB.lat,rB.lon, pE*half, pN*half)
        B_r=_offset(rB.lat,rB.lon,-pE*half,-pN*half)
        coords=" ".join([f"{A_l[1]:.8f},{A_l[0]:.8f}", f"{A_r[1]:.8f},{A_r[0]:.8f}", f"{B_r[1]:.8f},{B_r[0]:.8f}", f"{B_l[1]:.8f},{B_l[0]:.8f}"])
        kml += ['<GroundOverlay>', f'  <name>row {i}</name>', '  <Icon>', f'    <href>{images_dir}/{row_paths[i].name}</href>', '  </Icon>', '  <gx:LatLonQuad>', f'    <coordinates>{coords}</coordinates>', '  </gx:LatLonQuad>', '</GroundOverlay>']
        used+=1
    kml += ['</Document>','</kml>']
    kmz=Path(out_dir,f'{base}_sidescan.kmz')
    with zipfile.ZipFile(kmz,'w',compression=zipfile.ZIP_DEFLATED) as zf:
        zf.writestr('doc.kml', "\n".join(kml))
        for p in row_paths[:used]:
            zf.write(p, f"{images_dir}/{p.name}")

    if MAKE_VIDEO and row_paths:
        writer=imageio.get_writer(str(Path(out_dir,f'{base}_waterfall.mp4')), fps=FPS, macro_block_size=1)
        try:
            rows_needed=max(1, VHEIGHT//ROW_H); cache=[]
            for i,p in enumerate(row_paths):
                arr=np.array(Image.open(p)); cache.append(arr)
                if len(cache)>rows_needed: cache.pop(0)
                if len(cache)==rows_needed:
                    frame=np.vstack(cache); h,w=frame.shape[:2]
                    hp=(h+1)//2*2; wp=(w+1)//2*2
                    if hp!=h or wp!=w:
                        pad=np.zeros((hp,wp,3), dtype=np.uint8); pad[:h,:w]=frame; frame=pad
                    writer.append_data(frame)
                    if i>=VMAX: break
        finally:
            writer.close()

    return {'rows': len(row_paths), 'out_dir': str(out_dir), 'crc_mode': CRC_MODE}
